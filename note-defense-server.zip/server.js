"use strict";
// ノート防衛隊 専用サーバー:ページ配信、ひろば/パーティーの中継、掲示板・順位・セーブの保存
const http=require("http"),fs=require("fs"),path=require("path"),crypto=require("crypto");
const {attach}=require("./ws-lite");const econ=require("./econ");
const PORT=process.env.PORT||3000,ADMIN=String(process.env.ADMIN_CODE||"");
const DATA=process.env.DATA_FILE||path.join(__dirname,"data.json");
const PAGE=path.join(__dirname,"index.html");
const PARTY_MAX=6,MSG_MAX=4096,DOC_MAX=262144,TRADES_MAX=500,SAVES_MAX=20000,CONN_PER_IP=30;

/* ---------- 保存 ---------- */
let docs=new Map();
try{docs=new Map(Object.entries(JSON.parse(fs.readFileSync(DATA,"utf8"))))}catch(e){}
let saveT=null;
function persist(){if(saveT)return;saveT=setTimeout(()=>{saveT=null;
 const tmp=DATA+".tmp";fs.writeFile(tmp,JSON.stringify(Object.fromEntries(docs)),e=>{if(!e)fs.rename(tmp,DATA,()=>{})})},2000)}
const countOf=pre=>{let n=0;for(const k of docs.keys())if(k.startsWith(pre))n++;return n};

/* ---------- 配信 ---------- */
const server=http.createServer((req,res)=>{const u=req.url.split("?")[0];
 if(u==="/health"){res.writeHead(200,{"content-type":"text/plain"});return res.end("ok")}
 if(u==="/"||u==="/index.html"){return fs.readFile(PAGE,(e,b)=>{if(e){res.writeHead(500);return res.end("error")}
  res.writeHead(200,{"content-type":"text/html; charset=utf-8","cache-control":"no-cache","x-content-type-options":"nosniff","x-frame-options":"SAMEORIGIN"});res.end(b)})}
 if(u==="/manifest.webmanifest"){res.writeHead(200,{"content-type":"application/manifest+json"});return res.end(JSON.stringify({name:"ノート防衛隊",short_name:"ノート防衛隊",start_url:"/",display:"fullscreen",background_color:"#1c2945",theme_color:"#1c2945",icons:[{src:"/icon-192.png",sizes:"192x192",type:"image/png"},{src:"/icon-512.png",sizes:"512x512",type:"image/png"}]}))}
 if(u==="/icon-192.png"||u==="/icon-512.png"){return fs.readFile(path.join(__dirname,u.slice(1)),(e,b)=>{if(e){res.writeHead(404);return res.end()}res.writeHead(200,{"content-type":"image/png","cache-control":"max-age=86400"});res.end(b)})}
 res.writeHead(404);res.end("not found")});

/* ---------- 接続 ---------- */
const rooms=new Map(); // name -> Map(client -> presence)
const ipCount=new Map();
const send=(c,o)=>{if(c.readyState===1)c.send(JSON.stringify(o))};
const peerInfo=(c,p)=>({peer:c.peer,by:c.uid,presence:p||{}});
function pushPeers(name,joined,left){const r=rooms.get(name);if(!r)return;const peers=[...r].map(([c,p])=>peerInfo(c,p));
 for(const c of r.keys())send(c,{op:"peers",room:name,peers,joined:joined||[],left:left||[]})}
function leave(c,name){const r=rooms.get(name);if(!r||!r.has(c))return;const info=peerInfo(c,r.get(c));r.delete(c);c.rooms.delete(name);
 if(!r.size){if(name)rooms.delete(name)}else pushPeers(name,[],[info])}
function clean(v,max){return String(v==null?"":v).replace(/[\u0000-\u001f\u007f]/g,"").slice(0,max)}
function bucket(c){const t=Date.now();c.tok=Math.min(80,c.tok+(t-c.tokT)*.04);c.tokT=t;if(c.tok<1)return false;c.tok--;return true}

/* ---------- データの決まり ---------- */
const FC_A="ABCDEFGHJKLMNPQRSTUVWXYZ23456789",FC_RE=/^[A-Z2-9]{8}$/;
function fcOf(uid){const ih=x=>{let h=2166136261;for(let i=0;i<x.length;i++){h^=x.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0};let a=ih(uid+"|1"),b=ih(uid+"|2"),r="";for(let i=0;i<4;i++){r+=FC_A[a&31];a>>>=5}for(let i=0;i<4;i++){r+=FC_A[b&31];b>>>=5}return r}
const UNIT=/^[a-z]{2,16}$/;
const promoKey=x=>clean(x,20).trim().toUpperCase();
function canRead(c,p){const s=p.split("/");if(s[0]==="data")return s[1]==="users"&&s[2]===c.uid;if(s[0]==="freq"){const d=docs.get(p);return !!d&&(d.to===c.code||d.from===c.code)}return s[0]==="trades"||s[0]==="ranks"}
function writeRule(c,op,p,body){const s=p.split("/");const cur=docs.get(p);
 if(s[0]==="data"&&s[1]==="users"&&s[2]===c.uid&&s[3]==="save"&&s.length===4){
  if(op==="delete")return null;if(!cur&&countOf("data/users/")>=SAVES_MAX)return"quota_exceeded";return null}
 if(s[0]==="ranks"&&s.length===2){if(op==="delete")return c.admin?null:"invalid_argument";if(s[1]!==c.uid||typeof body.wave!=="number")return"invalid_argument";body.nick=clean(body.nick,10);return null}
 if(s[0]==="trades"&&s.length===2){if(op==="delete"&&c.admin)return null;return"invalid_argument"}
 if(s[0]==="freq"&&s.length===2){
  if(op==="delete"){if(!cur||cur.to===c.code||cur.from===c.code)return null;return"invalid_argument"}
  if(op!=="set"||body.from!==c.code||!FC_RE.test(body.to||"")||s[1]!==body.to+"_"+c.code||!["req","ok","del"].includes(body.kind))return"invalid_argument";
  if(!cur&&(countOf("freq/"+body.to+"_")>=100||countOf("freq/")>=20000))return"quota_exceeded";body.nick=clean(body.nick,10);body.at=Date.now();return null}
 return"invalid_argument"}
const subs=new Set();let notifyT=new Map();
function runSub(s){let rows=[];const pre=s.col+"/";const depth=s.col.split("/").length+1;
 for(const[k,v]of docs)if(k.startsWith(pre)&&k.split("/").length===depth&&(s.col!=="freq"||v.to===s.c.code)&&(s.col!=="trades"||!v.to||v.to===s.c.code||v.owner===s.c.uid))rows.push({id:k.slice(pre.length),data:v});
 if(s.order)rows.sort((a,b)=>{const x=a.data[s.order],y=b.data[s.order];return (x<y?-1:x>y?1:0)*(s.dir==="desc"?-1:1)});
 const total=rows.length;if(s.limit)rows=rows.slice(0,s.limit);
 send(s.c,{op:"snap",sid:s.sid,docs:rows,size:rows.length,total})}
function touched(p){const col=p.split("/").slice(0,-1).join("/");if(notifyT.has(col))return;notifyT.set(col,setTimeout(()=>{notifyT.delete(col);for(const s of subs)if(s.col===col)runSub(s)},80))}
const validPath=p=>typeof p==="string"&&p.length<300&&/^[A-Za-z0-9_\-.~:@+]+(\/[A-Za-z0-9_\-.~:@+]+)*$/.test(p);

const wss=attach(server,"/ws",DOC_MAX+4096,(c,req)=>{
 const ip=String(req.headers["x-forwarded-for"]||req.socket.remoteAddress||"").split(",")[0];
 const n=(ipCount.get(ip)||0)+1;ipCount.set(ip,n);c.ip=ip;
 c.peer=crypto.randomBytes(8).toString("hex");c.uid=null;c.rooms=new Set();c.tok=80;c.tokT=Date.now();c.admin=false;c.chatT=0;c.alive=true;
 if(n>CONN_PER_IP){c.close();}
 c.on("pong",()=>{c.alive=true});
 c.on("message",raw=>{let m;try{m=JSON.parse(raw)}catch(e){return}if(!m||typeof m!=="object")return;
  const reply=(o)=>{if(m.rid)send(c,Object.assign({op:"res",rid:m.rid},o))};
  if(m.op==="hello"){if(typeof m.token!=="string"||m.token.length<16||m.token.length>128)return c.close();
   c.uid="u_"+crypto.createHash("sha256").update(m.token).digest("hex").slice(0,22);c.code=fcOf(c.uid);
   return send(c,{op:"welcome",uid:c.uid,peer:c.peer})}
  if(!c.uid)return;
  if(m.op!=="set"&&!bucket(c))return reply({err:"resource_exhausted"});
  switch(m.op){
  case"admin":c.admin=!!ADMIN&&String(m.code||"")===ADMIN;return reply({ok:c.admin});
  case"join":{const name=String(m.room||"");if(name&&!/^[a-z0-9][a-z0-9_.-]{0,47}$/.test(name))return reply({err:"invalid_argument"});
   if(name&&c.rooms.size>=8)return reply({err:"limit_reached"});
   let r=rooms.get(name);if(!r){r=new Map();rooms.set(name,r)}
   if(name&&!r.has(c)&&r.size>=PARTY_MAX)return reply({err:"limit_reached"});
   const p=m.presence&&typeof m.presence==="object"?m.presence:{};if(JSON.stringify(p).length>MSG_MAX)return reply({err:"invalid_argument"});p.fc=c.code;r.set(c,p);c.rooms.add(name);reply({ok:true});return pushPeers(name,[peerInfo(c,p)],[])}
  case"leave":leave(c,String(m.room||""));return reply({ok:true});
  case"presence":{const r=rooms.get(String(m.room||""));if(!r||!r.has(c)||!m.patch)return;const nx=Object.assign({},r.get(c),m.patch);if(JSON.stringify(nx).length>MSG_MAX)return reply({err:"invalid_argument"});
   if(typeof nx.nick==="string")nx.nick=clean(nx.nick,10);nx.fc=c.code;r.set(c,nx);return pushPeers(String(m.room||""))}
  case"emit":{const name=String(m.room||""),r=rooms.get(name);if(!r||!r.has(c)||!["chat","party","invite"].includes(m.topic))return reply({err:"invalid_argument"});
   const d=m.data||{};if(JSON.stringify(d).length>MSG_MAX)return reply({err:"invalid_argument"});
   if(d.t==="dh"){const now=Date.now();if(now-(c.dhT||0)<700)return reply({ok:true});c.dhT=now;d.a=Math.max(0,Math.min(2100,+d.a||0))}
   if(m.topic==="chat"||d.t==="chat"){const t=Date.now();if(t-c.chatT<500)return reply({err:"resource_exhausted"});c.chatT=t;d.x=clean(d.x,80);d.n=clean(d.n,10);if(!d.x)return}
   if(m.topic==="invite"){if(name||!FC_RE.test(d.to||""))return reply({err:"invalid_argument"});d.f=c.code;d.n=clean(d.n,10);for(const o of r.keys())if(o.code===d.to)send(o,{op:"msg",room:name,topic:m.topic,data:d,peer:c.peer,by:c.uid});return reply({ok:true})}
   for(const o of r.keys())send(o,{op:"msg",room:name,topic:m.topic,data:d,peer:c.peer,by:c.uid});return reply({ok:true})}
  case"econ":{if(m.eop==="redeem"){const now=Date.now();if(now-(c.redeemW||0)>60000){c.redeemW=now;c.redeemN=0}if(++c.redeemN>10)return reply({err:"slow"})}
   const r=econ.handle(c,m,{docs,persist,rooms,clean,promoKey,touched});if(r.err)return reply({err:r.err});const out=Object.assign({},r);if(r.w){out.wallet=econ.seal(r.w);delete out.w}return reply(out)}
  case"redeem_old":{const now=Date.now();if(now-(c.redeemW||0)>60000){c.redeemW=now;c.redeemN=0}if(++c.redeemN>10)return reply({err:"slow"});
   const key="promo/"+promoKey(m.code),d=docs.get(key);if(!d)return reply({err:"not_found"});d.used=d.used||{};if(d.used[c.uid])return reply({err:"used"});if(d.max&&d.count>=d.max)return reply({err:"empty"});
   d.used[c.uid]=1;d.count=(d.count||0)+1;persist();return reply({ok:true,coins:d.coins,gems:d.gems||0,units:d.units})}
  case"promo-set":{if(!c.admin)return reply({err:"not_admin"});const k=promoKey(m.code);if(!k)return reply({err:"invalid_argument"});const key="promo/"+k;if(docs.has(key))return reply({err:"exists"});
   const units={};if(m.units&&typeof m.units==="object")for(const u of Object.keys(m.units).slice(0,40))if(UNIT.test(u))units[u]=Math.max(1,Math.min(99,m.units[u]|0));
   docs.set(key,{code:k,coins:Math.max(0,Math.min(1000000,m.coins|0)),gems:Math.max(0,Math.min(100000,m.gems|0)),units,max:Math.max(0,Math.min(100000,m.max|0)),count:0,used:{},at:Date.now()});persist();return reply({ok:true})}
  case"promo-del":{if(!c.admin)return reply({err:"not_admin"});docs.delete("promo/"+promoKey(m.code));persist();return reply({ok:true})}
  case"promo-list":{if(!c.admin)return reply({err:"not_admin"});const list=[];for(const[k,v]of docs)if(k.startsWith("promo/"))list.push({code:v.code,coins:v.coins,gems:v.gems||0,units:v.units,max:v.max,count:v.count||0});return reply({list})}
  case"get":{if(!validPath(m.path)||!canRead(c,m.path))return reply({exists:false});const v=docs.get(m.path);return reply({exists:!!v,data:v})}
  case"set":case"update":case"delete":{if(!validPath(m.path)||m.path.split("/").length%2)return reply({err:"invalid_argument"});
   if(!bucket(c))return reply({err:"resource_exhausted"});
   const body=m.op==="delete"?null:m.data;if(m.op!=="delete"&&(!body||typeof body!=="object"||Array.isArray(body)))return reply({err:"invalid_argument"});
   const err=writeRule(c,m.op,m.path,body);if(err)return reply({err});
   if(m.op==="delete")docs.delete(m.path);else if(m.op==="set")docs.set(m.path,body);else docs.set(m.path,Object.assign({},docs.get(m.path),body));
   persist();touched(m.path);return reply({ok:true})}
  case"sub":{if(typeof m.col!=="string"||!["trades","ranks","freq"].includes(m.col))return;const s={c,sid:m.sid,col:m.col,order:typeof m.order==="string"?m.order:null,dir:m.dir,limit:Math.min(1000,m.limit|0)||300};subs.add(s);return runSub(s)}
  }
 });
 c.on("close",()=>{ipCount.set(ip,(ipCount.get(ip)||1)-1);for(const name of [...c.rooms])leave(c,name);for(const s of subs)if(s.c===c)subs.delete(s)});
});
setInterval(()=>{for(const c of wss.clients){if(!c.alive){c.terminate();continue}c.alive=false;c.ping()}},25000);
function flush(){try{fs.writeFileSync(DATA,JSON.stringify(Object.fromEntries(docs)))}catch(e){}process.exit(0)}
process.on("SIGTERM",flush);process.on("SIGINT",flush);
server.listen(PORT,()=>console.log("note-defense listening on "+PORT));
