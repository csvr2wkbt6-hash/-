"use strict";
// ロケット工房 サーバー:ページ配信と、部屋(最大6人)の中継
const http=require("http"),fs=require("fs"),path=require("path"),crypto=require("crypto");
const {attach}=require("./ws-lite");
const PORT=process.env.PORT||3000,PAGE=path.join(__dirname,"index.html"),ROOM_MAX=6,MSG_MAX=60000;
const server=http.createServer((req,res)=>{const u=req.url.split("?")[0];
 if(u==="/health"){res.writeHead(200);return res.end("ok")}
 if(u==="/"||u==="/index.html")return fs.readFile(PAGE,(e,b)=>{if(e){res.writeHead(500);return res.end("error")}res.writeHead(200,{"content-type":"text/html; charset=utf-8","cache-control":"no-cache","x-content-type-options":"nosniff"});res.end(b)});
 if(u==="/manifest.webmanifest"){res.writeHead(200,{"content-type":"application/manifest+json"});return res.end(JSON.stringify({name:"ロケット工房",short_name:"ロケット工房",start_url:"/",display:"fullscreen",orientation:"any",background_color:"#0b1230",theme_color:"#0b1230",icons:[{src:"/icon-192.png",sizes:"192x192",type:"image/png"},{src:"/icon-512.png",sizes:"512x512",type:"image/png"}]}))}
 if(u==="/icon-192.png"||u==="/icon-512.png")return fs.readFile(path.join(__dirname,u.slice(1)),(e,b)=>{if(e){res.writeHead(404);return res.end()}res.writeHead(200,{"content-type":"image/png","cache-control":"max-age=86400"});res.end(b)});
 res.writeHead(404);res.end("not found")});
const clean=(v,m)=>String(v==null?"":v).replace(/[\u0000-\u001f\u007f<>]/g,"").slice(0,m);
const send=(c,o)=>{if(c.readyState===1)c.send(JSON.stringify(o))};
const all=new Set(),rooms=new Map(); // code -> {code,members:[conn],name,playing}
function members(r){return r.members.map(c=>({id:c.id,nick:c.nick}))}
function pushRoom(r){const m=members(r),host=r.members[0]?r.members[0].id:null;for(const c of r.members)send(c,{op:"members",room:r.code,members:m,host})}
let lobbyT=null;function lobby(){if(lobbyT)return;lobbyT=setTimeout(()=>{lobbyT=null;const list=[...rooms.values()].filter(r=>r.members.length).map(r=>({code:r.code,n:r.members.length,name:r.name,playing:!!r.playing}));for(const c of all)if(c.ready)send(c,{op:"lobby",online:[...all].filter(x=>x.ready).length,rooms:list})},300)}
function leave(c){const r=c.room&&rooms.get(c.room);c.room=null;if(!r)return;r.members=r.members.filter(x=>x!==c);if(!r.members.length)rooms.delete(r.code);else{if(r.members[0])r.name=r.members[0].nick+"の部屋";pushRoom(r)}lobby()}
const ipN=new Map();
const wss=attach(server,"/ws",MSG_MAX,(c,req)=>{const ip=String(req.headers["x-forwarded-for"]||req.socket.remoteAddress||"").split(",")[0];ipN.set(ip,(ipN.get(ip)||0)+1);
 c.id=crypto.randomBytes(6).toString("hex");c.nick="だれか";c.room=null;c.ready=false;c.alive=true;c.tok=120;c.tokT=Date.now();all.add(c);if(ipN.get(ip)>30)c.close();
 c.on("pong",()=>{c.alive=true});
 c.on("message",raw=>{const t=Date.now();c.tok=Math.min(120,c.tok+(t-c.tokT)*.06);c.tokT=t;if(c.tok<1)return;c.tok--;let m;try{m=JSON.parse(raw)}catch(e){return}if(!m||typeof m!=="object")return;
  if(m.op==="hello"){c.nick=clean(m.nick,10)||"だれか";c.ready=true;send(c,{op:"welcome",id:c.id});lobby();return}
  if(!c.ready)return;
  if(m.op==="nick"){c.nick=clean(m.nick,10)||"だれか";const r=c.room&&rooms.get(c.room);if(r)pushRoom(r);return}
  if(m.op==="join"){const code=clean(m.room,4).toLowerCase();if(!/^[a-z0-9]{4}$/.test(code))return send(c,{op:"joinerr",why:"コードは4文字です"});if(c.room===code)return;let r=rooms.get(code);if(!r){if(!m.create)return send(c,{op:"joinerr",why:"その部屋は見つかりません"});r={code,members:[],name:c.nick+"の部屋",playing:false};rooms.set(code,r)}if(r.members.length>=ROOM_MAX)return send(c,{op:"joinerr",why:"満員です(6人まで)"});leave(c);c.room=code;r.members.push(c);send(c,{op:"joined",room:code});pushRoom(r);lobby();return}
  if(m.op==="leave"){leave(c);send(c,{op:"left"});return}
  if(m.op==="state"){const r=c.room&&rooms.get(c.room);if(r&&r.members[0]===c){r.playing=!!m.playing;lobby()}return}
  if(m.op==="msg"){const r=c.room&&rooms.get(c.room);if(!r||!m.data||typeof m.data!=="object")return;const s=JSON.stringify(m.data);if(s.length>MSG_MAX)return;if(m.data.t==="chat"){if(t-(c.chatT||0)<600)return;c.chatT=t;m.data.x=clean(m.data.x,80);if(!m.data.x)return}
   const out=JSON.stringify({op:"msg",from:c.id,nick:c.nick,data:m.data});for(const o of r.members)if(o!==c&&(!m.to||o.id===m.to)&&o.readyState===1)o.send(out);return}
 });
 c.on("close",()=>{ipN.set(ip,(ipN.get(ip)||1)-1);leave(c);all.delete(c);lobby()})});
setInterval(()=>{for(const c of wss.clients){if(!c.alive){c.terminate();continue}c.alive=false;c.ping()}},25000);
server.listen(PORT,()=>console.log("rocket listening on "+PORT));
