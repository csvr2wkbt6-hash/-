"use strict";
// ノート防衛隊 専用サーバー:ページ配信、ひろば/パーティーの中継、掲示板・順位・セーブの保存
const http=require("http"),fs=require("fs"),path=require("path"),crypto=require("crypto");
const {attach}=require("./ws-lite");const econ=require("./econ");
const PORT=process.env.PORT||3000,ADMIN=String(process.env.ADMIN_CODE||"");
const DATA=process.env.DATA_FILE||path.join(__dirname,"data.json");
const PAGE=path.join(__dirname,"index.html");
const WORLD_MAX=14,PARTY_MAX=6,MSG_MAX=4096,DOC_MAX=262144,TRADES_MAX=500,SAVES_MAX=20000,CONN_PER_IP=30;

/* ---------- 保存 ---------- */
let docs=new Map();
try{docs=new Map(Object.entries(JSON.parse(fs.readFileSync(DATA,"utf8"))))}catch(e){}
let saveT=null;
function persist(){if(saveT)return;saveT=setTimeout(()=>{saveT=null;
 const tmp=DATA+".tmp";fs.writeFile(tmp,JSON.stringify(Object.fromEntries(docs)),e=>{if(!e)fs.rename(tmp,DATA,()=>{})})},2000)}
const countOf=pre=>{let n=0;for(const k of docs.keys())if(k.startsWith(pre))n++;return n};

/* ---------- 配信 ---------- */
const server=http.createServer((req,res)=>{const u=req.url.split("?")[0];
 if(u==="/health"){res.writeHead(200,{"content-type":"text/plain"});return res.end("ok")}
 if(u==="/"||u==="/index.html"){return fs.readFile(PAGE,(e,b)=>{if(e){res.writeHead(500);return res.end("error")}
  res.writeHead(200,{"content-type":"text/html; charset=utf-8","cache-control":"no-cache","x-content-type-options":"nosniff","x-frame-options":"SAMEORIGIN"});res.end(b)})}
 if(u==="/manifest.webmanifest"){res.writeHead(200,{"content-type":"application/manifest+json"});return res.end(JSON.stringify({name:"ノート防衛隊",short_name:"ノート防衛隊",start_url:"/",display:"fullscreen",background_color:"#1c2945",theme_color:"#1c2945",icons:[{src:"/icon-192.png",sizes:"192x192",type:"image/png"},{src:"/icon-512.png",sizes:"512x512",type:"image/png"}]}))}
 if(u==="/icon-192.png"||u==="/icon-512.png"){return fs.readFile(path.join(__dirname,u.slice(1)),(e,b)=>{if(e){res.writeHead(404);return res.end()}res.writeHead(200,{"content-type":"image/png","cache-control":"max-age=86400"});res.end(b)})}
 res.writeHead(404);res.end("not found")});

/* ---------- 接続 ---------- */
const rooms=new Map(); // name -> Map(client -> presence)
const ipCount=new Map();
const send=(c,o)=>{if(c.readyState===1)c.send(JSON.stringify(o))};
const peerInfo=(c,p)=>({peer:c.peer,by:c.uid,presence:p||{}});
function pushPeers(name,joined,left){const r=rooms.get(name);if(!r)return;const peers=[...r].map(([c,p])=>peerInfo(c,p));
 for(const c of r.keys())send(c,{op:"peers",room:name,peers,joined:joined||[],left:left||[]})}
function leave(c,name){const r=rooms.get(name);if(!r||!r.has(c))return;const info=peerInfo(c,r.get(c));r.delete(c);c.rooms.delete(name);
 if(!r.size){if(name)rooms.delete(name)}else pushPeers(name,[],[info])}
function clean(v,max){return String(v==null?"":v).replace(/[\u0000-\u001f\u007f]/g,"").slice(0,max)}
function bucket(c){const t=Date.now();c.tok=Math.min(80,c.tok+(t-c.tokT)*.04);c.tokT=t;if(c.tok<1)return false;c.tok--;return true}

/* ---------- データの決まり ---------- */
const FC_A="ABCDEFGHJKLMNPQRSTUVWXYZ23456789",FC_RE=/^[A-Z2-9]{8}$/;
function fcOf(uid){const ih=x=>{let h=2166136261;for(let i=0;i<x.length;i++){h^=x.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0};let a=ih(uid+"|1"),b=ih(uid+"|2"),r="";for(let i=0;i<4;i++){r+=FC_A[a&31];a>>>=5}for(let i=0;i<4;i++){r+=FC_A[b&31];b>>>=5}return r}
const UNIT=/^[a-z]{2,16}$/;
const promoKey=x=>clean(x,20).trim().toUpperCase();
function canRead(c,p){const s=p.split("/");if(s[0]==="data")return s[1]==="users"&&s[2]===c.uid;if(s[0]==="freq"){const d=docs.get(p);return !!d&&(d.to===c.code||d.from===c.code)}return s[0]==="trades"||s[0]==="ranks"}
function writeRule(c,op,p,body){const s=p.split("/");const cur=docs.get(p);
 if(s[0]==="data"&&s[1]==="users"&&s[2]===c.uid&&s[3]==="save"&&s.length===4){
  if(op==="delete")return null;if(!cur&&countOf("data/users/")>=SAVES_MAX)return"quota_exceeded";return null}
 if(s[0]==="ranks"&&s.length===2){if(op==="delete")return c.admin?null:"invalid_argument";if(s[1]!==c.uid||typeof body.wave!=="number")return"invalid_argument";body.nick=clean(body.nick,10);return null}
 if(s[0]==="trades"&&s.length===2){if(op==="delete"&&c.admin)return null;return"invalid_argument"}
 if(s[0]==="freq"&&s.length===2){
  if(op==="delete"){if(!cur||cur.to===c.code||cur.from===c.code)return null;return"invalid_argument"}
  if(op!=="set"||body.from!==c.code||!FC_RE.test(body.to||"")||s[1]!==body.to+"_"+c.code||!["req","ok","del"].includes(body.kind))return"invalid_argument";
  if(!cur&&(countOf("freq/"+body.to+"_")>=100||countOf("freq/")>=20000))return"quota_exceeded";body.nick=clean(body.nick,10);body.at=Date.now();return null}
 return"invalid_argument"}
const subs=new Set();let notifyT=new Map();
function runSub(s){let rows=[];const pre=s.col+"/";const depth=s.col.split("/").length+1;
 for(const[k,v]of docs)if(k.startsWith(pre)&&k.split("/").length===depth&&(s.col!=="freq"||v.to===s.c.code)&&(s.col!=="trades"||!v.to||v.to===s.c.code||v.owner===s.c.uid))rows.push({id:k.slice(pre.length),data:v});
 if(s.order)rows.sort((a,b)=>{const x=a.data[s.order],y=b.data[s.order];return (x<y?-1:x>y?1:0)*(s.dir==="desc"?-1:1)});
 const total=rows.length;if(s.limit)rows=rows.slice(0,s.limit);
 send(s.c,{op:"snap",sid:s.sid,docs:rows,size:rows.length,total})}
function touched(p){const col=p.split("/").slice(0,-1).join("/");if(notifyT.has(col))return;notifyT.set(col,setTimeout(()=>{notifyT.delete(col);for(const s of subs)if(s.col===col)runSub(s)},80))}
const validPath=p=>typeof p==="string"&&p.length<300&&/^[A-Za-z0-9_\-.~:@+]+(\/[A-Za-z0-9_\-.~:@+]+)*$/.test(p);

/* ---------- ラッキーブロックのベルト(オンラインの全員で取り合い) ---------- */
const BR=[["SECRET",.2],["UR",1.8],["SSR",7],["SR",16],["R",30],["N",45]],BR_LUCK=[["SECRET",1.5],["UR",8],["SSR",20],["SR",30],["R",25.5],["N",15]];
const BPRICE={N:60,R:180,SR:450,SSR:1200,UR:3500,SECRET:9000},BDUR=24000;
const belt={seq:1,items:[],ev:null,next:0,log:[]};
const evOn=k=>!!belt.ev&&belt.ev.kind===k&&Date.now()<belt.ev.until;
function bRoll(){const tb=evOn("luck")?BR_LUCK:BR;let r=Math.random()*100;for(const[k,p]of tb){if(r<p)return k;r-=p}return"N"}
const bPrice=it=>Math.round(BPRICE[it.r]*(evOn("half")?.5:1));
function bState(){const now=Date.now(),e=belt.ev&&now<belt.ev.until?belt.ev:null;return{now,items:belt.items.map(i=>[i.id,i.r,i.t0,i.dur,bPrice(i),i.by||""]),ev:e?{id:e.id,kind:e.kind,until:e.until,label:e.label}:null,log:belt.log.slice(-8)}}
function bCast(){const lob=rooms.get("");if(!lob)return;const d=bState();for(const o of lob.keys())send(o,{op:"msg",room:"",topic:"belt",data:d,peer:"",by:""})}
function bSpawn(r){belt.items.push({id:belt.seq++,r:r||bRoll(),t0:Date.now(),dur:BDUR})}
setInterval(()=>{const now=Date.now(),lob=rooms.get("");let ch=false;const n0=belt.items.length;belt.items=belt.items.filter(i=>i.by?now-i.soldAt<2500:now-i.t0<i.dur);if(belt.items.length!==n0)ch=true;
 if(belt.ev&&now>=belt.ev.until){belt.ev=null;ch=true}
 if(lob&&lob.size&&now>=belt.next){belt.next=now+(evOn("rain")?650:3000);if(belt.items.filter(i=>!i.by).length<40){bSpawn();ch=true}}
 if(ch)bCast()},250);
const WBX0=10,WBX1=50,WBZ=20;
function wposOk(c){const p=c.wpos;if(!p||Date.now()-p.t>4000)return null;const r=rooms.get(p.room);if(!r||!r.has(c))return null;return{p,slot:r.get(c).slot}}
/* 歩くブロック(部屋ごと) */
const WK=new Map();let wkSeq=1;const WSPD=2;
const wkPos=(k,now)=>{const q=Math.max(0,Math.min(1,(now-k.t0)/k.dur));return[k.fx+(k.tx-k.fx)*q,k.fz+(k.tz-k.fz)*q]};
const baseOf=s=>[6+(s%7)*8,s<7?5:35];
function wkCast(room){const r=rooms.get(room);if(!r)return;const now=Date.now(),list=(WK.get(room)||[]).map(k=>[k.id,k.r,k.nick,k.owner,k.fx,k.fz,k.tx,k.tz,k.t0,k.dur,k.price]);for(const o of r.keys())send(o,{op:"msg",room,topic:"world",data:{t:"wk",now,list},peer:"",by:""})}
function pendAdd(uid,key,val){const k="pend/"+uid,d=docs.get(k)||{blocks:[],crates:[]};(d[key]=d[key]||[]).push(val);if(d[key].length>60)d[key]=d[key].slice(-60);docs.set(k,d);persist();const lob=rooms.get("");if(lob)for(const o of lob.keys())if(o.uid===uid)send(o,{op:"msg",room:"",topic:"pend",data:{},peer:"",by:""})}
setInterval(()=>{const now=Date.now();for(const[room,list]of WK){let ch=false;for(const k of list)if(now>=k.t0+k.dur){k.done=true;ch=true;pendAdd(k.owner,"blocks",k.r)}if(ch){const nl=list.filter(k=>!k.done);if(nl.length)WK.set(room,nl);else WK.delete(room);wkCast(room)}}},250);
const beltApi={walking:uid=>{let n=0;for(const l of WK.values())for(const k of l)if(k.owner===uid&&!k.done)n++;return n},walkStart:(c,it,nick,price)=>{const q=wposOk(c);if(!q||typeof q.slot!=="number"||it.by)return null;const now=Date.now(),x=WBX0+(now-it.t0)/it.dur*(WBX1-WBX0);it.by=clean(nick,10)||"だれか";it.soldAt=now;const b=baseOf(q.slot),k={id:wkSeq++,r:it.r,owner:c.uid,nick:it.by,fx:x,fz:WBZ+(b[1]<WBZ?-1.4:1.4),tx:b[0],tz:b[1],t0:now,price};k.dur=Math.max(2000,Math.hypot(k.tx-k.fx,k.tz-k.fz)/WSPD*1000);const l=WK.get(q.p.room)||[];l.push(k);WK.set(q.p.room,l);bCast();wkCast(q.p.room);return k},
 wfind:(c,id)=>{const q=wposOk(c);if(!q)return null;return(WK.get(q.p.room)||[]).find(k=>k.id===id&&!k.done)||null},
 wnear:(c,k)=>{const q=wposOk(c);if(!q)return false;const p=wkPos(k,Date.now());return Math.hypot(q.p.x-p[0],q.p.z-p[1])<=3.4},
 wsteal:(c,k,nick)=>{const q=wposOk(c);if(!q||typeof q.slot!=="number"||k.done)return false;const now=Date.now(),p=wkPos(k,now),b=baseOf(q.slot);k.owner=c.uid;k.nick=clean(nick,10)||"だれか";k.fx=p[0];k.fz=p[1];k.tx=b[0];k.tz=b[1];k.t0=now;k.dur=Math.max(1500,Math.hypot(k.tx-k.fx,k.tz-k.fz)/WSPD*1000);wkCast(q.p.room);return true},
 near:(c,it)=>{const q=wposOk(c);if(!q)return false;const x=WBX0+(Date.now()-it.t0)/it.dur*(WBX1-WBX0);return Math.hypot(q.p.x-x,q.p.z-WBZ)<=3.6},atBase:c=>{const q=wposOk(c);if(!q||typeof q.slot!=="number")return false;const s=q.slot,bx=6+(s%7)*8,bz=s<7?5:35;return Math.hypot(q.p.x-bx,q.p.z-bz)<=4.2},log:(nick,r,id)=>{belt.log.push([clean(nick,10)||"だれか",r,id]);belt.log=belt.log.slice(-20);bCast()},find:id=>belt.items.find(i=>i.id===id&&!i.by&&Date.now()-i.t0<i.dur),price:bPrice,take:(it,nick)=>{if(it.by)return false;it.by=clean(nick,10)||"だれか";it.soldAt=Date.now();return true},after:()=>bCast(),gift:()=>evOn("gift")?belt.ev:null};
/* ---------- レイドの呼び出しとマッチング(最大8人) ---------- */
const RAID_EVERY=15*60000,RAID_WINDOW=Math.max(5000,Number(process.env.RAID_WINDOW)||45000);
const raid={call:null,next:Math.ceil(Date.now()/RAID_EVERY)*RAID_EVERY};
const raidMsg=()=>({t:"call",id:raid.call.id,k:raid.call.k,until:raid.call.until,now:Date.now()});
function raidStart(k){const now=Date.now();raid.call={id:crypto.randomBytes(4).toString("hex"),k:k>=1&&k<=3?k:1+Math.floor(Math.random()*3),until:now+RAID_WINDOW,groups:{0:[],1:[],2:[]}};const lob=rooms.get("");if(lob){const d=raidMsg();for(const o of lob.keys())send(o,{op:"msg",room:"",topic:"raid",data:d,peer:"",by:""})}}
setInterval(()=>{if(Date.now()>=raid.next){raid.next+=RAID_EVERY;if(raid.next<Date.now())raid.next=Math.ceil(Date.now()/RAID_EVERY)*RAID_EVERY;raidStart(0)}},1000);
const RC_A="abcdefghjkmnpqrstuvwxyz23456789";
const RAIDS=new Map(),RBASE={1:14000,2:19000,3:26000},RLVM=[1,4,12],RDMG=[22,34,48],RGAP=[3.4,2.6,1.9],RTIME=180000;
function rNew(k,lv,startAt){let code;do{code="";for(let i=0;i<4;i++)code+=RC_A[Math.floor(Math.random()*RC_A.length)]}while(RAIDS.has(code));const x={code,k,lv,startAt,state:"wait",hp:0,max:0,until:0,pl:new Map(),members:new Set(),atkT:0,aseq:1,castT:0};RAIDS.set(code,x);return x}
function rCast(x,d){const r=rooms.get("ra-"+x.code);if(!r)return;for(const o of r.keys())send(o,{op:"msg",room:"ra-"+x.code,topic:"raid",data:d,peer:"",by:""})}
function rState(x){const now=Date.now(),top=[...x.pl.values()].sort((a,b)=>b.dmg-a.dmg).slice(0,6).map(p=>[p.nick,Math.round(p.dmg)]);return{t:"rs",code:x.code,k:x.k,lv:x.lv,state:x.state,hp:Math.max(0,Math.round(x.hp)),max:x.max,left:x.state==="fight"?Math.max(0,x.until-now):0,startIn:Math.max(0,x.startAt-now),top,now}}
setInterval(()=>{const now=Date.now();for(const x of RAIDS.values()){const r=rooms.get("ra-"+x.code),n=r?r.size:0;
  if(x.state==="wait"&&now>=x.startAt){if(!n){RAIDS.delete(x.code);continue}x.state="fight";x.max=x.hp=Math.max(1,Math.round(RBASE[x.k]*RLVM[x.lv]*(1+.5*(n-1))*(Number(process.env.RAID_HP_MUL)||1)));x.until=now+RTIME;x.atkT=now+3000}
  if(x.state==="fight"){if(x.hp<=0){x.state="win";for(const[uid,p]of x.pl)if(p.dmg>0)pendAdd(uid,"crates",x.k+"-"+x.lv);x.endAt=now;rCast(x,Object.assign(rState(x),{t:"end",win:true}))}
   else if(now>=x.until||!n){x.state="lose";x.endAt=now;rCast(x,Object.assign(rState(x),{t:"end",win:false}))}
   else if(now>=x.atkT){const rage=x.hp<x.max/2;x.atkT=now+RGAP[x.lv]*1000*(rage?.7:1);const ps=r?[...r.keys()].map(o=>o.wpos&&o.wpos.room==="ra-"+x.code&&now-o.wpos.t<4000?o.wpos:null).filter(Boolean):[];
    const pats=[["circle","wave","rain","line","double"],["circle","wave","rain","line","spin","donut","double"],["circle","rain","line","spin","donut","cross","double"]][x.lv];let n=1;if(rage)n++;if(x.lv===2&&Math.random()<.45)n++;
    const used=new Set();for(let i=0;i<n;i++){const p=pats[Math.floor(Math.random()*pats.length)];if(used.has(p))continue;used.add(p);rAtk(x,p,now+i*500,ps,rage)}}}
  if((x.state==="win"||x.state==="lose")&&now-x.endAt>60000)RAIDS.delete(x.code);
  if(x.state==="wait"&&now-x.startAt>600000)RAIDS.delete(x.code);
  if(now-x.castT>=500&&(x.state==="wait"||x.state==="fight")){x.castT=now;rCast(x,rState(x))}}},250);
const RCX=30,RCZ=20,RR=18,RBRS=4.6;
function rAtk(x,p,at0,ps,rage){const now=Date.now(),D=RDMG[x.lv],B=(o)=>rCast(x,Object.assign({t:"atk",id:x.aseq++,dmg:D,now},o));
 if(p==="circle"&&!ps.length)p="rain";
 if(p==="circle")for(const q of ps.slice(0,8)){B({kind:"circle",x:q.x+(Math.random()-.5)*2,z:q.z+(Math.random()-.5)*2,r:3+x.lv*.5,at:at0+1500-x.lv*150});if(x.lv>=1||rage)B({kind:"circle",x:q.x+(Math.random()-.5)*7,z:q.z+(Math.random()-.5)*7,r:2.6,at:at0+2300})}
 if(p==="rain"){const n=10+x.lv*5+(rage?4:0);for(let i=0;i<n;i++){const a=Math.random()*6.283,d=RBRS+1+Math.random()*(RR-RBRS-1.5);B({kind:"circle",x:RCX+Math.cos(a)*d,z:RCZ+Math.sin(a)*d,r:1.8+x.lv*.2,at:at0+1300+Math.random()*800})}}
 if(p==="wave")B({kind:"wave",at:at0+1400,speed:7+x.lv*1.5});
 if(p==="double"){B({kind:"wave",at:at0+1400,speed:7+x.lv*1.5});B({kind:"wave",at:at0+2200,speed:7+x.lv*1.5});if(x.lv>=2&&rage)B({kind:"wave",at:at0+3000,speed:9})}
 if(p==="line"){const k=2+x.lv,a0=Math.random()*Math.PI;for(let i=0;i<k;i++)B({kind:"line",a:a0+i*Math.PI/k,w:1.8,at:at0+1600-x.lv*150})}
 if(p==="cross"){const a0=Math.random()*Math.PI;for(let i=0;i<4;i++)B({kind:"line",a:a0+i*Math.PI/4,w:1.6,at:at0+1400+i*350})}
 if(p==="spin")B({kind:"spin",a:Math.random()*6.283,spd:(Math.random()<.5?-1:1)*(1.1+x.lv*.3),at:at0+1500,dur:3600+x.lv*600,w:1.3});
 if(p==="donut")B({kind:"donut",r:RBRS+3.2,at:at0+2200-x.lv*200})}
function raidDmg(c,m){const x=RAIDS.get(String(m.code||""));if(!x||x.state!=="fight")return{err:"gone"};const r=rooms.get("ra-"+x.code);if(!r||!r.has(c))return{err:"invalid_argument"};const now=Date.now();let p=x.pl.get(c.uid);if(!p){p={nick:"だれか",dmg:0,last:now-1000,qT:0};x.pl.set(c.uid,p)}p.nick=clean(m.nick,10)||p.nick;
 const dt=Math.min(5,Math.max(0,(now-p.last)/1000));p.last=now;const pw=Math.max(5,c.rpow||5);let q=0;if((m.q|0)>0&&now-p.qT>4000){q=1;p.qT=now}const cap=pw*dt*1.3+q*pw*8;const d=Math.max(0,Math.min(+m.d||0,cap));x.hp-=d;p.dmg+=d;return{ok:true,hp:Math.max(0,Math.round(x.hp))}}
function raidJoin(c,id,lv){const cl=raid.call;if(!cl||cl.id!==id||Date.now()>cl.until+5000)return{err:"gone"};if(![0,1,2].includes(lv))return{err:"invalid_argument"};const gs=cl.groups[lv];
 let g=gs.find(x=>x.members.has(c.uid)&&RAIDS.has(x.code));if(!g){g=gs.find(x=>x.members.size<8&&RAIDS.has(x.code)&&x.state==="wait");if(!g){g=rNew(cl.k,lv,cl.until);gs.push(g)}g.members.add(c.uid)}
 return{code:g.code,k:cl.k,lv,startIn:Math.max(0,g.startAt-Date.now())}}
const wss=attach(server,"/ws",DOC_MAX+4096,(c,req)=>{
 const ip=String(req.headers["x-forwarded-for"]||req.socket.remoteAddress||"").split(",")[0];
 const n=(ipCount.get(ip)||0)+1;ipCount.set(ip,n);c.ip=ip;
 c.peer=crypto.randomBytes(8).toString("hex");c.uid=null;c.rooms=new Set();c.tok=80;c.tokT=Date.now();c.admin=false;c.chatT=0;c.alive=true;
 if(n>CONN_PER_IP){c.close();}
 c.on("pong",()=>{c.alive=true});
 c.on("message",raw=>{let m;try{m=JSON.parse(raw)}catch(e){return}if(!m||typeof m!=="object")return;
  const reply=(o)=>{if(m.rid)send(c,Object.assign({op:"res",rid:m.rid},o))};
  if(m.op==="hello"){if(typeof m.token!=="string"||m.token.length<16||m.token.length>128)return c.close();
   c.uid="u_"+crypto.createHash("sha256").update(m.token).digest("hex").slice(0,22);c.code=fcOf(c.uid);
   return send(c,{op:"welcome",uid:c.uid,peer:c.peer})}
  if(!c.uid)return;
  if(m.op!=="set"&&!bucket(c))return reply({err:"resource_exhausted"});
  switch(m.op){
  case"admin":c.admin=!!ADMIN&&String(m.code||"")===ADMIN;return reply({ok:c.admin});
  case"join":{const name=String(m.room||"");if(name&&!/^[a-z0-9][a-z0-9_.-]{0,47}$/.test(name))return reply({err:"invalid_argument"});
   if(name&&c.rooms.size>=8)return reply({err:"limit_reached"});
   let r=rooms.get(name);if(!r){r=new Map();rooms.set(name,r)}
   const isW=/^w-[1-9]$/.test(name);if(name&&!r.has(c)&&r.size>=(isW?WORLD_MAX:name.startsWith("pt-rd")||name.startsWith("ra-")?8:PARTY_MAX))return reply({err:"limit_reached"});
   const p=m.presence&&typeof m.presence==="object"?m.presence:{};if(JSON.stringify(p).length>MSG_MAX)return reply({err:"invalid_argument"});p.fc=c.code;if(isW){const old=r.get(c);if(old&&typeof old.slot==="number")p.slot=old.slot;else{const used=new Set([...r.values()].map(v=>v.slot));let s=0;while(used.has(s))s++;p.slot=s}}else delete p.slot;r.set(c,p);c.rooms.add(name);reply({ok:true});pushPeers(name,[peerInfo(c,p)],[]);if(isW)setTimeout(()=>wkCast(name),50);
   if(!name){send(c,{op:"msg",room:"",topic:"belt",data:bState(),peer:"",by:""});if(docs.has("pend/"+c.uid))send(c,{op:"msg",room:"",topic:"pend",data:{},peer:"",by:""});if(raid.call&&Date.now()<raid.call.until)send(c,{op:"msg",room:"",topic:"raid",data:raidMsg(),peer:"",by:""})}return}
  case"leave":leave(c,String(m.room||""));return reply({ok:true});
  case"presence":{const r=rooms.get(String(m.room||""));if(!r||!r.has(c)||!m.patch)return;const nx=Object.assign({},r.get(c),m.patch);if(JSON.stringify(nx).length>MSG_MAX)return reply({err:"invalid_argument"});
   if(typeof nx.nick==="string")nx.nick=clean(nx.nick,10);nx.fc=c.code;nx.slot=r.get(c).slot;if(nx.slot===undefined)delete nx.slot;r.set(c,nx);return pushPeers(String(m.room||""))}
  case"emit":{const name=String(m.room||""),r=rooms.get(name);if(!r||!r.has(c)||!["chat","party","invite","world"].includes(m.topic))return reply({err:"invalid_argument"});if(m.topic==="world"&&!/^(w-[1-9]|ra-[a-z0-9]{4})$/.test(name))return reply({err:"invalid_argument"});
   const d=m.data||{};if(JSON.stringify(d).length>MSG_MAX)return reply({err:"invalid_argument"});
   if(m.topic==="world"){if(d.t!=="p")return reply({err:"invalid_argument"});const x=+d.x,z=+d.z;if(!isFinite(x)||!isFinite(z))return reply({err:"invalid_argument"});c.wpos={room:name,x:Math.max(0,Math.min(60,x)),z:Math.max(0,Math.min(40,z)),t:Date.now()};d.c=["N","R","SR","SSR","UR","SECRET"].includes(d.c)?d.c:""}
   if(d.t==="dh"){const now=Date.now();if(now-(c.dhT||0)<700)return reply({ok:true});c.dhT=now;d.a=Math.max(0,Math.min(2100,+d.a||0))}
   if(m.topic==="chat"||d.t==="chat"){const t=Date.now();if(t-c.chatT<500)return reply({err:"resource_exhausted"});c.chatT=t;d.x=clean(d.x,80);d.n=clean(d.n,10);if(!d.x)return}
   if(m.topic==="invite"){if(name||!FC_RE.test(d.to||""))return reply({err:"invalid_argument"});d.f=c.code;d.n=clean(d.n,10);for(const o of r.keys())if(o.code===d.to)send(o,{op:"msg",room:name,topic:m.topic,data:d,peer:c.peer,by:c.uid});return reply({ok:true})}
   for(const o of r.keys())send(o,{op:"msg",room:name,topic:m.topic,data:d,peer:c.peer,by:c.uid});return reply({ok:true})}
  case"econ":{if(m.eop==="redeem"){const now=Date.now();if(now-(c.redeemW||0)>60000){c.redeemW=now;c.redeemN=0}if(++c.redeemN>10)return reply({err:"slow"})}
   const r=econ.handle(c,m,{docs,persist,rooms,clean,promoKey,touched,belt:beltApi});
   if(m.eop==="bopen"&&r.id){const lob=rooms.get("");if(lob)for(const id of [r.id])if(econ.isRare(id))for(const o of lob.keys())send(o,{op:"msg",room:"",topic:"news",data:{n:clean(m.nick,10),id},peer:c.peer,by:c.uid})}if(r.err)return reply({err:r.err});
   if(m.eop==="gacha"&&r.ids){const lob=rooms.get("");if(lob)for(const id of r.ids){if(econ.isRare(id))for(const o of lob.keys())send(o,{op:"msg",room:"",topic:"news",data:{n:clean(m.nick,10),id},peer:c.peer,by:c.uid})}}const out=Object.assign({},r);if(r.w){out.wallet=econ.seal(r.w);delete out.w}return reply(out)}
  case"redeem_old":{const now=Date.now();if(now-(c.redeemW||0)>60000){c.redeemW=now;c.redeemN=0}if(++c.redeemN>10)return reply({err:"slow"});
   const key="promo/"+promoKey(m.code),d=docs.get(key);if(!d)return reply({err:"not_found"});d.used=d.used||{};if(d.used[c.uid])return reply({err:"used"});if(d.max&&d.count>=d.max)return reply({err:"empty"});
   d.used[c.uid]=1;d.count=(d.count||0)+1;persist();return reply({ok:true,coins:d.coins,gems:d.gems||0,units:d.units})}
  case"promo-set":{if(!c.admin)return reply({err:"not_admin"});const k=promoKey(m.code);if(!k)return reply({err:"invalid_argument"});const key="promo/"+k;if(docs.has(key))return reply({err:"exists"});
   const units={};if(m.units&&typeof m.units==="object")for(const u of Object.keys(m.units).slice(0,40))if(UNIT.test(u))units[u]=Math.max(1,Math.min(99,m.units[u]|0));
   docs.set(key,{code:k,coins:Math.max(0,Math.min(1000000,m.coins|0)),gems:Math.max(0,Math.min(100000,m.gems|0)),units,max:Math.max(0,Math.min(100000,m.max|0)),count:0,used:{},at:Date.now()});persist();return reply({ok:true})}
  case"raid-join":return reply(raidJoin(c,String(m.id||""),m.lv|0));
  case"raid-solo":{const k=m.k|0,lv=m.lv|0;if(k<1||k>3||lv<0||lv>2)return reply({err:"invalid_argument"});const x=rNew(k,lv,Date.now()+(m.party?9000:4000));x.members.add(c.uid);return reply({code:x.code,k,lv,startIn:x.startAt-Date.now()})}
  case"raid-dmg":return reply(raidDmg(c,m));
  case"raid-call":{if(!c.admin)return reply({err:"not_admin"});raidStart(m.k|0);return reply({ok:true})}
  case"belt-admin":{if(!c.admin)return reply({err:"not_admin"});const k=String(m.kind||""),now=Date.now(),nid=crypto.randomBytes(4).toString("hex");
   const L={rain:["ブロックの雨!(1分)",60000],luck:["ラッキータイム!レアが出やすい(3分)",180000],half:["半額セール!(3分)",180000]};
   if(k==="stop"){belt.ev=null;bCast();return reply({ok:true})}
   if(k==="secret"||k==="ur"){bSpawn(k==="secret"?"SECRET":"UR");belt.ev={id:nid,kind:k,until:now+20000,label:k==="secret"?"シークレットブロック出現!":"URブロック出現!"};bCast();return reply({ok:true})}
   if(k==="gift"){const a=Math.max(1,Math.min(5000,m.amount|0||500));belt.ev={id:nid,kind:"gift",until:now+600000,label:"みんなにプレゼント!コイン "+a,amount:a};bCast();return reply({ok:true})}
   if(!L[k])return reply({err:"invalid_argument"});belt.ev={id:nid,kind:k,until:now+L[k][1],label:L[k][0]};if(k==="rain")belt.next=0;bCast();return reply({ok:true})}
  case"promo-del":{if(!c.admin)return reply({err:"not_admin"});docs.delete("promo/"+promoKey(m.code));persist();return reply({ok:true})}
  case"promo-list":{if(!c.admin)return reply({err:"not_admin"});const list=[];for(const[k,v]of docs)if(k.startsWith("promo/"))list.push({code:v.code,coins:v.coins,gems:v.gems||0,units:v.units,max:v.max,count:v.count||0});return reply({list})}
  case"get":{if(!validPath(m.path)||!canRead(c,m.path))return reply({exists:false});const v=docs.get(m.path);return reply({exists:!!v,data:v})}
  case"set":case"update":case"delete":{if(!validPath(m.path)||m.path.split("/").length%2)return reply({err:"invalid_argument"});
   if(!bucket(c))return reply({err:"resource_exhausted"});
   const body=m.op==="delete"?null:m.data;if(m.op!=="delete"&&(!body||typeof body!=="object"||Array.isArray(body)))return reply({err:"invalid_argument"});
   const err=writeRule(c,m.op,m.path,body);if(err)return reply({err});
   if(m.op==="delete")docs.delete(m.path);else if(m.op==="set")docs.set(m.path,body);else docs.set(m.path,Object.assign({},docs.get(m.path),body));
   persist();touched(m.path);return reply({ok:true})}
  case"sub":{if(typeof m.col!=="string"||!["trades","ranks","freq"].includes(m.col))return;const s={c,sid:m.sid,col:m.col,order:typeof m.order==="string"?m.order:null,dir:m.dir,limit:Math.min(1000,m.limit|0)||300};subs.add(s);return runSub(s)}
  }
 });
 c.on("close",()=>{ipCount.set(ip,(ipCount.get(ip)||1)-1);for(const name of [...c.rooms])leave(c,name);for(const s of subs)if(s.c===c)subs.delete(s)});
});
setInterval(()=>{for(const c of wss.clients){if(!c.alive){c.terminate();continue}c.alive=false;c.ping()}},25000);
function flush(){try{fs.writeFileSync(DATA,JSON.stringify(Object.fromEntries(docs)))}catch(e){}process.exit(0)}
process.on("SIGTERM",flush);process.on("SIGINT",flush);
server.listen(PORT,()=>console.log("note-defense listening on "+PORT));
