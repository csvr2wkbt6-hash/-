"use strict";
// 追加インストール不要の小さなWebSocketサーバー(RFC 6455)
const crypto=require("crypto"),{EventEmitter}=require("events");
const GUID="258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
class Conn extends EventEmitter{
 constructor(sock,max){super();this.sock=sock;this.max=max;this.readyState=1;this.buf=Buffer.alloc(0);this.parts=[];this.partLen=0;this.opcode=0;
  sock.on("data",d=>this._data(d));sock.on("close",()=>this._closed());sock.on("error",()=>this._closed());sock.setNoDelay(true)}
 _closed(){if(this.readyState===3)return;this.readyState=3;this.emit("close")}
 _frame(op,p){const n=p.length;let h;if(n<126){h=Buffer.from([0x80|op,n])}else if(n<65536){h=Buffer.alloc(4);h[0]=0x80|op;h[1]=126;h.writeUInt16BE(n,2)}else{h=Buffer.alloc(10);h[0]=0x80|op;h[1]=127;h.writeUInt32BE(0,2);h.writeUInt32BE(n,6)}
  if(this.sock.writable)this.sock.write(Buffer.concat([h,p]))}
 send(s){if(this.readyState===1)this._frame(1,Buffer.from(s))}
 ping(){if(this.readyState===1)this._frame(9,Buffer.alloc(0))}
 close(){if(this.readyState===1){this._frame(8,Buffer.alloc(0));this.readyState=2;this.sock.end();this._closed()}}
 terminate(){this.sock.destroy();this._closed()}
 _data(d){this.buf=this.buf.length?Buffer.concat([this.buf,d]):d;if(this.buf.length>this.max+16)return this.terminate();
  while(this.buf.length>=2&&this.readyState===1){const b=this.buf,fin=b[0]&0x80,op=b[0]&15,masked=b[1]&0x80;let len=b[1]&127,o=2;
   if(!masked)return this.terminate();
   if(len===126){if(b.length<4)return;len=b.readUInt16BE(2);o=4}else if(len===127){if(b.length<10)return;if(b.readUInt32BE(2)!==0)return this.terminate();len=b.readUInt32BE(6);o=10}
   if(len>this.max)return this.terminate();
   if(b.length<o+4+len)return;
   const mask=b.subarray(o,o+4),p=Buffer.from(b.subarray(o+4,o+4+len));for(let i=0;i<len;i++)p[i]^=mask[i%4];
   this.buf=b.subarray(o+4+len);
   if(op===8){this.close();return}
   if(op===9){this._frame(10,p);continue}
   if(op===10){this.emit("pong");continue}
   if(op===1||op===2){this.opcode=op;this.parts=[];this.partLen=0}else if(op!==0)return this.terminate();
   this.parts.push(p);this.partLen+=len;if(this.partLen>this.max)return this.terminate();
   if(fin){const all=Buffer.concat(this.parts);this.parts=[];this.emit("message",all.toString("utf8"))}
  }}
}
function attach(server,wsPath,max,onConn){const clients=new Set();
 server.on("upgrade",(req,sock)=>{sock.on("error",()=>{});
  const key=req.headers["sec-websocket-key"];
  const origin=req.headers.origin;let okOrigin=true;if(origin){try{okOrigin=new URL(origin).host===req.headers.host}catch(e){okOrigin=false}}
  if(req.url.split("?")[0]!==wsPath||!key||!okOrigin){sock.write("HTTP/1.1 403 Forbidden\r\n\r\n");return sock.destroy()}
  const acc=crypto.createHash("sha1").update(key+GUID).digest("base64");
  sock.write("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: "+acc+"\r\n\r\n");
  const c=new Conn(sock,max);clients.add(c);c.on("close",()=>clients.delete(c));onConn(c,req)});
 return{clients}}
module.exports={attach};
