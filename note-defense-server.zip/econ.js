"use strict";
// コイン・ダイヤ・キャラの管理。データはサーバーの署名付きで端末に保存する
const crypto=require("crypto"),fs=require("fs"),path=require("path");
const G=JSON.parse(fs.readFileSync(path.join(__dirname,"gamedata.json"),"utf8"));
const SECRET=process.env.SAVE_SECRET||"";
const MIGRATE_UNTIL=Date.parse(process.env.MIGRATE_UNTIL||"2026-11-10T00:00:00+09:00");
const U=G.UNITS,IDS=Object.keys(U);
const hmac=s=>crypto.createHmac("sha256",SECRET).update(s).digest("base64url");
const seal=o=>{const w=JSON.stringify(o);return{w,sig:hmac(w)}};
const eq=(a,b)=>{const x=Buffer.from(String(a)),y=Buffer.from(String(b));return x.length===y.length&&crypto.timingSafeEqual(x,y)};
function unseal(b){if(!b||typeof b.w!=="string"||!eq(hmac(b.w),b.sig))return null;try{return JSON.parse(b.w)}catch(e){return null}}
const jst=()=>new Date(Date.now()+9*3600000);
const today=()=>jst().toISOString().slice(0,10);
const evKey=()=>jst().toISOString().slice(0,7);
const month=()=>jst().getUTCMonth()+1;
function season(){const m=month();return m>=3&&m<=5?"spring":m>=6&&m<=8?"summer":m>=9&&m<=11?"autumn":"winter"}
function fresh(){return{v:1,coins:200,gems:0,inv:{pencil:1,eraser:1,ruler:1},stat:{},done:{},first:{},promo:[],listings:{},resets:{d:"",n:0},daily:"",lt:0,ev:null}}
function ev(w){const k=evKey();if(!w.ev||w.ev.key!==k)w.ev={key:k,coins:0,stat:{},done:{}};return w.ev}
function bump(w,k,n){if(!n)return;w.stat[k]=(w.stat[k]||0)+n;const e=ev(w);e.stat[k]=(e.stat[k]||0)+n}
const add=(w,id,n)=>{w.inv[id]=(w.inv[id]||0)+(n||1)};
function rem(w,id){w.inv[id]=(w.inv[id]||0)-1;if(w.inv[id]<=0)delete w.inv[id];if(!w.inv.pencil)w.inv.pencil=1}
const trad=(w,id)=>id==="pencil"?(w.inv[id]||0)>1:(w.inv[id]||0)>0;
const pool=r=>IDS.filter(i=>U[i].r===r&&!U[i].season&&!U[i].event);
const pick=a=>a[Math.floor(Math.random()*a.length)];
function roll(rates){let r=Math.random()*100;for(const[k,p]of rates){if(r<p)return k;r-=p}return rates[rates.length-1][0]}
function gacha(w,m){const n=m.n===10?10:1,b=m.banner,ids=[];
 if(b==="ev"){const e=ev(w),c=n*10;if(e.coins<c)return{err:"short"};e.coins-=c;const E=G.EVENTS[month()];for(let i=0;i<n;i++){const k=roll(G.EV_RATES);ids.push(k==="SECRET"?E[2]:k==="EV"?E[1]:pick(pool(k)))}}
 else{const gem=b==="gem",sea=b==="season";if(!gem&&!sea&&b!=="normal")return{err:"invalid_argument"};const cost=gem?(n===10?270:30):sea?(n===10?1080:120):(n===10?900:100);if((gem?w.gems:w.coins)<cost)return{err:"short"};if(gem)w.gems-=cost;else w.coins-=cost;const lim=IDS.filter(i=>U[i].season===season()),rates=gem?G.GEM_RATES:G.RATES;
  for(let i=0;i<n;i++)ids.push(sea&&Math.random()<.02?pick(lim):pick(pool(roll(rates))))}
 ids.forEach(i=>add(w,i));bump(w,"pulls",n);return{ids}}
function settle(w,docs,persist){let got=[];for(const id of Object.keys(w.listings)){const l=w.listings[id],k="trades/"+id,d=docs.get(k);
  if(d&&d.status==="done"){if(l.want){add(w,l.want);bump(w,"trades",1);got.push(l.want)}delete w.listings[id];docs.delete(k);persist()}
  else if(!d){add(w,l.give);delete w.listings[id];got.push(l.give)}}return{got}}
function legacy(s){const w=fresh();if(!s||typeof s!=="object")return w;const num=(v,m)=>Math.max(0,Math.min(m,Math.floor(+v||0)));w.coins=num(s.coins,30000);w.gems=num(s.gems,3000);if(s.inv&&typeof s.inv==="object")for(const k of Object.keys(s.inv))if(U[k])w.inv[k]=num(s.inv[k],99);if(!w.inv.pencil)w.inv.pencil=1;if(s.stat&&typeof s.stat==="object")for(const k of Object.keys(s.stat))w.stat[k]=num(s.stat[k],1e7);if(s.done&&typeof s.done==="object")for(const k of Object.keys(s.done))w.done[k]=1;if(Array.isArray(s.promo))w.promo=s.promo.slice(-200).map(String);return w}
// c:接続 m:要求 ctx:{docs,persist,rooms,clean}
function handle(c,m,ctx){const{docs,persist,clean}=ctx;if(!SECRET)return{err:"no_secret"};const op=m.eop;
 if(op==="open"){let w=m.wallet?unseal(m.wallet):null;let note=null;if(m.wallet&&!w){w=fresh();note="reset"}if(!w){if(Date.now()<MIGRATE_UNTIL&&m.legacy){w=legacy(m.legacy);note="migrated"}else{w=fresh();note="new"}}return{w,note}}
 if(op==="bstart"){const t=Date.now();return{ticket:seal({k:m.kind==="dun"?"dun":"st",i:m.i|0,t})}}
 const w=unseal(m.wallet);if(!w)return{err:"bad_wallet"};let out={};
 switch(op){
 case"sync":break;
 case"daily":{if(w.daily===today()){out.same=true;break}w.daily=today();w.coins+=50;w.gems+=5;bump(w,"login",1);out.bonus=true;break}
 case"gacha":{const r=gacha(w,m);if(r.err)return r;out=r;break}
 case"mission":{const list=m.ev?G.EV_MISSIONS:G.MISSIONS,x=list.find(y=>y.id===m.id);if(!x)return{err:"invalid_argument"};if(m.ev){const e=ev(w);if(e.done[x.id]||(e.stat[x.stat]||0)<x.goal)return{err:"not_ready"};e.done[x.id]=1;e.coins+=x.c}else{if(w.done[x.id]||(w.stat[x.stat]||0)<x.goal)return{err:"not_ready"};w.done[x.id]=1;w.coins+=x.coin}break}
 case"reset":{const r=w.resets||{};const used=r.d===today()?(r.n||0):0;if(!c.admin&&used>=2)return{err:"limit"};const nw=fresh();nw.resets={d:today(),n:used+1};nw.daily=w.daily;nw.lt=w.lt;nw.listings=w.listings;return{w:nw}}
 case"admin":{if(!c.admin)return{err:"not_admin"};w.coins+=Math.max(0,Math.min(1e6,m.coins|0));w.gems+=Math.max(0,Math.min(1e6,m.gems|0));ev(w).coins+=Math.max(0,Math.min(1e5,m.ev|0));if(m.all)IDS.forEach(i=>add(w,i));break}
 case"bend":{const tk=unseal(m.ticket);if(!tk)return{err:"bad_ticket"};if(tk.t<=(w.lt||0))return{err:"used_ticket"};if(Date.now()-tk.t>12*3600000)return{err:"old_ticket"};w.lt=tk.t;const sec=(Date.now()-tk.t)/1000;
  let n=1;if(m.room&&ctx.rooms.get(String(m.room))&&ctx.rooms.get(String(m.room)).has(c))n=Math.max(1,ctx.rooms.get(String(m.room)).size);const win=!!m.win;let gain=0,gems=0,evc=0,reject=false;
  if(tk.k==="dun"){if(!G.DUNN||tk.i<0||tk.i>=G.DUNN)return{err:"invalid_argument"};if(win&&sec<10+tk.i&&!c.admin)reject=true;else{if(win){const k="d"+tk.i,f=!w.first[k];w.first[k]=1;gain=(80+40*tk.i)*(f?2:1);if(f)gems=10;bump(w,"dungeon",1);evc=1}else gain=Math.round(Math.max(0,Math.min(1,+m.frac||0))*30);if(m.money)gain*=(w.inv[m.money]&&U[m.money]&&U[m.money].kind==="income")?2:1;bump(w,"quiz",Math.max(0,Math.min(m.quiz|0,Math.floor(sec/10))))}}
  else{const st=G.STAGES[tk.i];if(!st)return{err:"invalid_argument"};const reached=Math.max(0,Math.min(m.reached|0,Math.ceil(sec/2.5)));const endless=st.waves===null;if(win&&!endless&&!c.admin&&sec<st.waves*4)reject=true;else{if(endless)gain=reached*8;else if(st.rush){const lv=st.rush,k="s"+tk.i,f=win&&!w.first[k];if(win)w.first[k]=1;gain=win?(f?1000*lv:400*lv):reached*30*lv;if(f)gems=20;if(win)bump(w,"rush",1)}else if(win){const k="s"+tk.i,f=!w.first[k]&&!(m.old&&tk.i<4&&w.stat.wins);w.first[k]=1;gain=(60+30*tk.i)*(f?2:1);if(f)gems=10}else gain=reached*5;
    if(win){bump(w,"wins",1);evc=1}bump(w,"kills",Math.max(0,Math.min(m.kills|0,Math.ceil(sec*6))));bump(w,"bosses",Math.max(0,Math.min(m.bosses|0,Math.ceil(sec/2))))}}
  if(reject){out.rejected=true;break}if(n>1){gain=Math.round(gain*(1+.3*(n-1)));bump(w,"party",1)}w.coins+=gain;w.gems+=gems;ev(w).coins+=evc;out.gain=gain;out.gems=gems;out.evc=evc;break}
 case"mk-list":{const give=m.give,want=m.want||"";if(!U[give]||!trad(w,give))return{err:"short"};if(want&&!U[want])return{err:"invalid_argument"};if(!want&&!m.to)return{err:"invalid_argument"};if(Object.keys(w.listings).length>=5)return{err:"limit"};let cnt=0;for(const k of docs.keys())if(k.startsWith("trades/"))cnt++;if(cnt>=500)return{err:"quota_exceeded"};const id=Date.now().toString(36)+crypto.randomBytes(5).toString("hex");const d={owner:c.uid,nick:clean(m.nick,10),give,want,status:"open",at:Date.now()};if(m.to){if(!/^[A-Z2-9]{8}$/.test(m.to))return{err:"invalid_argument"};d.to=m.to}docs.set("trades/"+id,d);rem(w,give);w.listings[id]={give,want};persist();ctx.touched("trades/"+id);out.id=id;break}
 case"mk-accept":{const k="trades/"+String(m.id),d=docs.get(k);if(!d||d.status!=="open")return{err:"gone"};if(d.owner===c.uid)return{err:"invalid_argument"};if(d.to&&d.to!==c.code)return{err:"invalid_argument"};if(d.want&&!trad(w,d.want))return{err:"short"};if(d.want)rem(w,d.want);add(w,d.give);bump(w,"trades",1);d.status="done";d.buyer=c.uid;persist();ctx.touched(k);out.got=d.give;break}
 case"mk-decline":{const k="trades/"+String(m.id),d=docs.get(k);if(d&&d.to===c.code&&d.status==="open"){docs.delete(k);persist();ctx.touched(k)}break}
 case"mk-cancel":{const id=String(m.id),k="trades/"+id,d=docs.get(k);if(!w.listings[id])return{err:"gone"};if(d&&d.status==="done"){const r=settle(w,docs,persist);ctx.touched(k);out.got=r.got;break}add(w,w.listings[id].give);delete w.listings[id];if(d){docs.delete(k);persist();ctx.touched(k)}break}
 case"mk-settle":{out=settle(w,docs,persist);break}
 case"redeem":{const key=ctx.promoKey(m.code),dk="promo/"+key,d=docs.get(dk);if(!d)return{err:"not_found"};w.promo=w.promo||[];d.used=d.used||{};if(d.used[c.uid]||w.promo.includes(key))return{err:"used"};if(d.max&&d.count>=d.max)return{err:"empty"};d.used[c.uid]=1;d.count=(d.count||0)+1;persist();w.coins+=d.coins||0;w.gems+=d.gems||0;for(const u of Object.keys(d.units||{}))if(U[u])add(w,u,d.units[u]);w.promo.push(key);w.promo=w.promo.slice(-200);out.coins=d.coins;out.gems=d.gems||0;out.units=d.units;break}
 default:return{err:"invalid_argument"}}
 ev(w);return Object.assign(out,{w})}
module.exports={handle,seal,hasSecret:()=>!!SECRET};
